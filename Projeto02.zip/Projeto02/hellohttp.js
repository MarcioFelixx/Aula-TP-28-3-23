//Importar bibilioteca que use o protocolo http e url
const http = require('http');
const url = require('url');
const fs = require('fs');

//criar uma função para trabalhar no servidor
function readFile(response, file){
    fs.readFile(file, function(err,data){
        response.end(data)
    });
}

var callback = function (request, response){
    response.writeHead(200, {"Content-type": "text/plain"});
    
var parts = url.parse(request.url);
var path = parts.path;

    if (parts.path == "/"){
        response.writeHead(200, {"Content-type": "text/html"});
        readFile(response, "batata.html")
    } else if(parts.path == "/rota1"){
        response.writeHead(200, {"Content-type": "application.pdf"});
        readFile(response, "livro.pdf")
    } else if(parts.path == "/rota2"){
        response.writeHead(200, {"Content-type": "application.json"});
        readFile(response, "cadastro.json")
    } else if(parts.path == "/rota3"){
        response.writeHead(200, {"Content-type": "image.jpg"});
        readFile(response, "imagem.jpg")
    } else if(parts.path == "/rota4"){
        response.writeHead(200, {"Content-type": "application.zip"});
        readFile(response, "download.zip")
    } else if(parts.path == "/rota5"){
        response.writeHead(200, {"Content-type": "text/html"});
        readFile(response, "Area do aluno.html")
    } else if(parts.path == "/rota6"){
        response.writeHead(200, {"Content-type": "text/html"});
        readFile(response, "unicsul.html")
    }
    else {
        response.writeHead(200, {"Content-type": "text/html"});
        response.end("404.html")
    }
}

//criar o servidor
var server = http.createServer(callback)
//configurar a porta que vai ser utilizada
server.listen(3000);
//mostrar mensagem no terminal para mostrar status do web server
console.log("[SERVER]... Servidor montado em http://localhost:3000")